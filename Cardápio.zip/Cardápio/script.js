function calcularPedido() {
  const codigo = parseInt(document.getElementById('codigo').value);
  const quantidade = parseInt(document.getElementById('quantidade').value);

  const cardapio = {
    1: { nome: 'Cachorro Quente', preco: 11.00 },
    2: { nome: 'Bauru', preco: 8.50 },
    3: { nome: 'Misto Quente', preco: 8.00 },
    4: { nome: 'Hamburguer', preco: 9.00 },
    5: { nome: 'Cheeseburger', preco: 10.00 },
    6: { nome: 'Refrigerante', preco: 4.50 },
  };

  const item = cardapio[codigo];

  if (item && quantidade > 0) {
    const total = item.preco * quantidade;
    document.getElementById('resultado').innerHTML =
      `Produto: ${item.nome}<br>Quantidade: ${quantidade}<br>Total a pagar: R$ ${total.toFixed(2)}`;
  } else {
    document.getElementById('resultado').innerHTML = 'Código inválido ou quantidade incorreta.';
  }
}