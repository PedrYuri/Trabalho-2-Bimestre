function calcularImposto() {
    const ano = parseInt(document.getElementById('ano').value);
    const valor = parseFloat(document.getElementById('valor').value);
    const resultado = document.getElementById('resultado');

    if (ano > 0 && valor > 0) {
        let taxa = ano < 1990 ? 0.01 : 0.015;
        let imposto = valor * taxa;

        resultado.textContent = `Imposto a pagar: R$ ${imposto.toFixed(2)}`;
    } else {
        resultado.textContent = "Por favor, insira valores válidos.";
    }
}