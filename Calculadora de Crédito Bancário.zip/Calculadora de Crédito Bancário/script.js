function calcularCredito() {
  const saldo = parseFloat(document.getElementById('saldo').value);
  let percentual = 0;

  if (saldo <= 200) {
    percentual = 0;
  } else if (saldo <= 400) {
    percentual = 20;
  } else if (saldo <= 600) {
    percentual = 30;
  } else {
    percentual = 40;
  }

  const credito = saldo * (percentual / 100);

  let mensagem = `Saldo médio: R$ ${saldo.toFixed(2)}<br>`;
  mensagem += percentual === 0 
    ? "Nenhum crédito disponível." 
    : `Crédito concedido: R$ ${credito.toFixed(2)}`;

  document.getElementById('resultado').innerHTML = mensagem;
}