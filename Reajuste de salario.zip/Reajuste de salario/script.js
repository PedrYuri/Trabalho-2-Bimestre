function calcularSalario() {
  const salario = parseFloat(document.getElementById('salario').value);
  const codigo = parseInt(document.getElementById('codigo').value);
  let percentual = 0;

  switch (codigo) {
    case 101:
      percentual = 10;
      break;
    case 102:
      percentual = 20;
      break;
    case 103:
      percentual = 30;
      break;
    default:
      percentual = 40;
  }

  const aumento = salario * (percentual / 100);
  const novoSalario = salario + aumento;

  document.getElementById('resultado').innerHTML = `
    Salário antigo: R$ ${salario.toFixed(2)}<br>
    Novo salário: R$ ${novoSalario.toFixed(2)}<br>
    Diferença: R$ ${aumento.toFixed(2)}
  `;
}